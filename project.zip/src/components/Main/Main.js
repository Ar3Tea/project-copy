import React from "react"

const Main = () => (
  <div className="lead text-light p-t-30 p-b-30 p-l-100 p-r-100">
    Constituents of Peterborough - time is running out - sign the recall
    petition and get rid of this criminal MP
  </div>
)

export default Main
